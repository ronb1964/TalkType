/* extension.js
 *
 * TalkType GNOME Shell Extension
 * Provides native GNOME integration for TalkType speech recognition
 */

import GObject from 'gi://GObject';
import St from 'gi://St';
import Gio from 'gi://Gio';
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

// D-Bus interface for TalkType
const TalkTypeIface = `
<node>
  <interface name="io.github.ronb1964.TalkType">
    <!-- Properties/Status -->
    <method name="IsRecording">
      <arg type="b" direction="out" name="recording"/>
    </method>
    <method name="IsServiceRunning">
      <arg type="b" direction="out" name="running"/>
    </method>
    <method name="GetCurrentModel">
      <arg type="s" direction="out" name="model"/>
    </method>
    <method name="GetDeviceType">
      <arg type="s" direction="out" name="device"/>
    </method>
    <method name="GetStatus">
      <arg type="a{sv}" direction="out" name="status"/>
    </method>

    <!-- Actions -->
    <method name="StartRecording"/>
    <method name="StopRecording"/>
    <method name="ToggleRecording"/>
    <method name="StartService"/>
    <method name="StopService"/>
    <method name="SetModel">
      <arg type="s" direction="in" name="model"/>
    </method>
    <method name="OpenPreferences"/>
    <method name="Quit"/>

    <!-- Signals -->
    <signal name="RecordingStateChanged">
      <arg type="b" name="is_recording"/>
    </signal>
    <signal name="ServiceStateChanged">
      <arg type="b" name="is_running"/>
    </signal>
    <signal name="TranscriptionComplete">
      <arg type="s" name="text"/>
    </signal>
    <signal name="ModelChanged">
      <arg type="s" name="model_name"/>
    </signal>
    <signal name="ErrorOccurred">
      <arg type="s" name="error_type"/>
      <arg type="s" name="message"/>
    </signal>
  </interface>
</node>`;

const TalkTypeProxy = Gio.DBusProxy.makeProxyWrapper(TalkTypeIface);

// Panel indicator for TalkType
const TalkTypeIndicator = GObject.registerClass(
class TalkTypeIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'TalkType');

        // Create icon
        this._icon = new St.Icon({
            icon_name: 'audio-input-microphone-symbolic',
            style_class: 'system-status-icon',
        });
        this.add_child(this._icon);

        // State
        this._isRecording = false;
        this._isServiceRunning = false;
        this._currentModel = 'unknown';

        // Connect to D-Bus
        this._connectDBus();

        // Build menu
        this._buildMenu();

        // Update status
        this._updateStatus();
    }

    _connectDBus() {
        try {
            this._proxy = new TalkTypeProxy(
                Gio.DBus.session,
                'io.github.ronb1964.TalkType',
                '/io/github/ronb1964/TalkType'
            );

            // Connect to signals
            this._proxy.connectSignal('RecordingStateChanged', (proxy, sender, [isRecording]) => {
                this._isRecording = isRecording;
                this._updateIcon();
            });

            this._proxy.connectSignal('ServiceStateChanged', (proxy, sender, [isRunning]) => {
                this._isServiceRunning = isRunning;
                this._updateIcon();
            });

            this._proxy.connectSignal('ModelChanged', (proxy, sender, [modelName]) => {
                this._currentModel = modelName;
                this._updateMenu();
            });

            console.log('TalkType: Connected to D-Bus service');
        } catch (e) {
            console.error('TalkType: Failed to connect to D-Bus:', e);
        }
    }

    _buildMenu() {
        // Service start/stop
        this._serviceItem = new PopupMenu.PopupSwitchMenuItem('Dictation Service', false);
        this._serviceItem.connect('toggled', (item) => {
            if (item.state) {
                this._proxy.StartServiceRemote();
            } else {
                this._proxy.StopServiceRemote();
            }
        });
        this.menu.addMenuItem(this._serviceItem);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Quick model switcher
        let modelSection = new PopupMenu.PopupMenuSection();
        let modelLabel = new PopupMenu.PopupMenuItem('Model Selection', {reactive: false});
        modelLabel.label.style = 'font-weight: bold;';
        modelSection.addMenuItem(modelLabel);

        const models = [
            {name: 'tiny', label: 'Tiny (fastest)'},
            {name: 'base', label: 'Base'},
            {name: 'small', label: 'Small'},
            {name: 'medium', label: 'Medium'},
            {name: 'large-v3', label: 'Large (best quality)'}
        ];

        this._modelItems = [];
        models.forEach(model => {
            let item = new PopupMenu.PopupMenuItem(model.label);
            item.connect('activate', () => {
                this._proxy.SetModelRemote(model.name);
            });
            modelSection.addMenuItem(item);
            this._modelItems.push({item, name: model.name});
        });

        this.menu.addMenuItem(modelSection);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Preferences
        let prefsItem = new PopupMenu.PopupMenuItem('Preferences...');
        prefsItem.connect('activate', () => {
            this._proxy.OpenPreferencesRemote();
        });
        this.menu.addMenuItem(prefsItem);
    }

    _updateStatus() {
        if (!this._proxy)
            return;

        // Get current status
        this._proxy.GetStatusRemote((result, error) => {
            if (error) {
                console.error('TalkType: Failed to get status:', error);
                return;
            }

            let [status] = result;
            this._isRecording = status.recording || false;
            this._isServiceRunning = status.service_running || false;
            this._currentModel = status.model || 'unknown';

            this._updateIcon();
            this._updateMenu();
        });
    }

    _updateIcon() {
        // Change icon based on state
        if (this._isRecording) {
            this._icon.icon_name = 'media-record-symbolic';
            this._icon.style_class = 'system-status-icon recording-active';
        } else if (this._isServiceRunning) {
            this._icon.icon_name = 'audio-input-microphone-symbolic';
            this._icon.style_class = 'system-status-icon';
        } else {
            this._icon.icon_name = 'audio-input-microphone-symbolic';
            this._icon.style_class = 'system-status-icon service-inactive';
            this._icon.opacity = 128;
        }
    }

    _updateMenu() {
        // Update service switch
        this._serviceItem.setToggleState(this._isServiceRunning);

        // Update model checkmarks
        this._modelItems.forEach(({item, name}) => {
            if (name === this._currentModel) {
                item.setOrnament(PopupMenu.Ornament.CHECK);
            } else {
                item.setOrnament(PopupMenu.Ornament.NONE);
            }
        });
    }

    destroy() {
        if (this._proxy) {
            this._proxy = null;
        }
        super.destroy();
    }
});

export default class TalkTypeExtension extends Extension {
    enable() {
        console.log('TalkType Extension: Enabling...');

        this._indicator = new TalkTypeIndicator();
        Main.panel.addToStatusArea('talktype', this._indicator);

        console.log('TalkType Extension: Enabled');
    }

    disable() {
        console.log('TalkType Extension: Disabling...');

        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }

        console.log('TalkType Extension: Disabled');
    }
}
